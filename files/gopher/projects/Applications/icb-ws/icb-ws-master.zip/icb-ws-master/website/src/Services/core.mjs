export const ConnectionState = Object.freeze({
  UNDEFINED: 'undefined',
  DISCONNECTED: 'disconnected',
  CONNECTING: 'connecting',
  CONNECTED: 'connected'
})
