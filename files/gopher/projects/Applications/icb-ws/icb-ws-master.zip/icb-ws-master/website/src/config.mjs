export const Config = Object.freeze({
  url: 'ws://localhost:7329',
  loginid: 'webuser',
  defaultNick: '',
  defaultGroup: '1'
})
